import { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Customer',
};


export default function Page() {
    return <p>Customers Page</p>;
}